# MOVIORA — Android starter

This is the first runnable React Native / Expo foundation for MOVIORA.

## Included
- Arabic RTL-first dark cinematic interface
- Home, discover, saved list, and profile tabs
- Search and category filters
- Detail sheet for catalogue entries
- Save/remove favourites in app memory
- Player screen placeholder
- MOVIORA black, gold, and purple visual identity

## Important
The included catalogue is illustrative starter data, not a complete licensed streaming catalogue.
The player is a UI placeholder. Real playback requires lawful video sources (for example, authorized HLS/DASH streams), a backend catalogue, and appropriate content rights.
Login, VIP payments, admin tools, cloud sync, and production security are not yet connected.

## Run
1. Install Node.js on a computer.
2. Extract this project.
3. Open a terminal in the MOVIORA folder.
4. Run `npm install`
5. Run `npx expo start`
6. Scan the QR code with Expo Go on Android.

## Build an Android APK
For a production APK, configure an Expo EAS project and Android signing credentials, then use:
`npx eas-cli build -p android --profile preview`

See Expo's current EAS Build documentation before publishing. Never share signing keys or payment secrets.
