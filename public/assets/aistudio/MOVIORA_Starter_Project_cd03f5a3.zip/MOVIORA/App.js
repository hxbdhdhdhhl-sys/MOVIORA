import React, { useMemo, useState } from "react";
import {
  SafeAreaView, View, Text, TextInput, ScrollView, Pressable,
  StatusBar, Modal, Platform
} from "react-native";
import { StatusBar as ExpoStatusBar } from "expo-status-bar";

const C = {
  bg: "#09090D", panel: "#15151D", panel2: "#20202A", gold: "#D9B56D",
  text: "#F5F1E8", muted: "#A5A1AA", line: "#30303A", purple: "#7560A8"
};

// Starter catalogue: illustrative entries only. Replace with verified, licensed catalogue data.
const ITEMS = [
  {id:"1", title:"Band of Brothers", ar:"إخوة السلاح", year:"2001", country:"الولايات المتحدة", genre:"الحرب العالمية الثانية", kind:"مسلسل", description:"دراما تاريخية تتناول تجربة مجموعة من الجنود خلال الحرب العالمية الثانية.", seasons:"موسم واحد", color:"#5B5142"},
  {id:"2", title:"The Pacific", ar:"المحيط الهادئ", year:"2010", country:"الولايات المتحدة", genre:"الحرب العالمية الثانية", kind:"مسلسل", description:"عمل درامي تاريخي عن جبهة المحيط الهادئ.", seasons:"موسم واحد", color:"#35545B"},
  {id:"3", title:"Generation War", ar:"جيل الحرب", year:"2013", country:"ألمانيا", genre:"الحرب العالمية الثانية", kind:"مسلسل", description:"دراما ألمانية تاريخية من خمسة أجزاء.", seasons:"موسم واحد", color:"#62504B"},
  {id:"4", title:"The Unknown War", ar:"الحرب المجهولة", year:"1978", country:"الاتحاد السوفيتي", genre:"وثائقي حربي", kind:"وثائقي", description:"سلسلة وثائقية عن الجبهة الشرقية في الحرب العالمية الثانية.", seasons:"سلسلة وثائقية", color:"#675B43"},
  {id:"5", title:"The Thaw", ar:"فترة الذوبان", year:"2013", country:"روسيا", genre:"دراما تاريخية", kind:"مسلسل", description:"دراما تدور أحداثها في الوسط السينمائي السوفيتي خلال خمسينيات القرن العشرين.", seasons:"موسم واحد", color:"#554B70"},
  {id:"6", title:"The Last Kingdom", ar:"المملكة الأخيرة", year:"2015", country:"بريطانيا", genre:"تاريخي", kind:"مسلسل", description:"دراما تاريخية تدور في إنجلترا خلال عصر الممالك.", seasons:"عدة مواسم", color:"#6C4B3F"},
  {id:"7", title:"Rome", ar:"روما", year:"2005", country:"بريطانيا / الولايات المتحدة", genre:"تاريخي", kind:"مسلسل", description:"دراما تاريخية عن التحولات السياسية والاجتماعية في روما القديمة.", seasons:"موسمان", color:"#754D3E"},
  {id:"8", title:"World on Fire", ar:"العالم يحترق", year:"2019", country:"بريطانيا", genre:"الحرب العالمية الثانية", kind:"مسلسل", description:"دراما متعددة الشخصيات تدور أحداثها خلال الحرب العالمية الثانية.", seasons:"موسمان", color:"#47576B"}
];

const tabs = [
  ["home","الرئيسية"],["discover","اكتشف"],["saved","قائمتي"],["profile","حسابي"]
];

function Pill({label, active, onPress}) {
  return <Pressable onPress={onPress} style={{paddingHorizontal:14,paddingVertical:9,borderRadius:22,backgroundColor:active?C.gold:C.panel2,marginRight:8}}>
    <Text style={{color:active?C.bg:C.text,fontWeight:"700",fontSize:12}}>{label}</Text>
  </Pressable>;
}

function Poster({item, onPress, compact=false}) {
  return <Pressable onPress={onPress} style={{width:compact?142:160,marginRight:12}}>
    <View style={{height:compact?190:215,borderRadius:14,backgroundColor:item.color,justifyContent:"space-between",padding:12,borderWidth:1,borderColor:"#ffffff18"}}>
      <Text style={{color:"#FFFFFFAA",fontSize:10,fontWeight:"800",letterSpacing:1}}>MOVIORA</Text>
      <View>
        <Text style={{color:"#fff",fontSize:18,fontWeight:"900",textAlign:"right"}}>{item.ar}</Text>
        <Text style={{color:"#FFFFFFCC",fontSize:10,marginTop:5}}>{item.year}  •  {item.country}</Text>
      </View>
    </View>
    <Text numberOfLines={1} style={{color:C.text,fontWeight:"700",marginTop:8,textAlign:"right"}}>{item.ar}</Text>
    <Text numberOfLines={1} style={{color:C.muted,fontSize:11,marginTop:3,textAlign:"right"}}>{item.genre}</Text>
  </Pressable>;
}

export default function App() {
  const [tab,setTab] = useState("home");
  const [query,setQuery] = useState("");
  const [filter,setFilter] = useState("الكل");
  const [saved,setSaved] = useState([]);
  const [selected,setSelected] = useState(null);
  const [player,setPlayer] = useState(false);

  const filtered = useMemo(() => ITEMS.filter(x => {
    const q = query.trim().toLowerCase();
    const matches = !q || [x.title,x.ar,x.country,x.genre].some(v=>v.toLowerCase().includes(q));
    const cat = filter==="الكل" || x.genre.includes(filter) || x.country.includes(filter);
    return matches && cat;
  }),[query,filter]);

  const toggleSaved = id => setSaved(prev => prev.includes(id)?prev.filter(x=>x!==id):[...prev,id]);
  const heading = tab==="home"?"اكتشف عالم الحكايات":tab==="discover"?"اكتشف المحتوى":tab==="saved"?"قائمتي":"حسابك";

  return <SafeAreaView style={{flex:1,backgroundColor:C.bg}}>
    <ExpoStatusBar style="light"/>
    <StatusBar barStyle="light-content" backgroundColor={C.bg}/>
    <View style={{paddingHorizontal:18,paddingTop:Platform.OS==="android"?12:6,paddingBottom:12,flexDirection:"row",alignItems:"center",justifyContent:"space-between"}}>
      <View>
        <Text style={{color:C.gold,fontSize:25,fontWeight:"900",letterSpacing:2}}>MOVIORA</Text>
        <Text style={{color:C.muted,fontSize:10,letterSpacing:2}}>CINEMA • SERIES • HISTORY</Text>
      </View>
      <View style={{width:38,height:38,borderRadius:13,backgroundColor:C.panel,alignItems:"center",justifyContent:"center",borderWidth:1,borderColor:C.line}}>
        <Text style={{color:C.gold,fontSize:17}}>✦</Text>
      </View>
    </View>

    <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{paddingBottom:30}}>
      <View style={{paddingHorizontal:18}}>
        <View style={{backgroundColor:"#211C2A",borderRadius:20,padding:20,borderWidth:1,borderColor:"#594A6D"}}>
          <Text style={{color:C.gold,fontSize:11,fontWeight:"800",letterSpacing:2,textAlign:"right"}}>YOUR CINEMA DESTINATION</Text>
          <Text style={{color:C.text,fontSize:25,fontWeight:"900",textAlign:"right",marginTop:10}}>{heading}</Text>
          <Text style={{color:"#C9C1D1",fontSize:13,textAlign:"right",lineHeight:22,marginTop:8}}>اكتشف الدراما التاريخية والأعمال العالمية والأرشيف السوفيتي في مكان واحد.</Text>
          <Pressable onPress={()=>{setTab("discover");setFilter("الكل");}} style={{alignSelf:"flex-end",backgroundColor:C.gold,paddingHorizontal:18,paddingVertical:11,borderRadius:12,marginTop:15}}>
            <Text style={{color:C.bg,fontWeight:"900"}}>استكشف المكتبة  ←</Text>
          </Pressable>
        </View>
      </View>

      <View style={{paddingHorizontal:18,marginTop:18}}>
        <TextInput value={query} onChangeText={setQuery} placeholder="ابحث عن مسلسل أو فيلم أو دولة..." placeholderTextColor="#77737E"
          style={{backgroundColor:C.panel,borderWidth:1,borderColor:C.line,borderRadius:13,paddingHorizontal:15,paddingVertical:13,color:C.text,textAlign:"right"}}/>
      </View>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{paddingHorizontal:18,paddingVertical:16,flexDirection:"row-reverse"}}>
        {["الكل","الحرب العالمية الثانية","وثائقي حربي","دراما تاريخية","تاريخي","روسيا","الاتحاد السوفيتي"].map(x=><Pill key={x} label={x} active={filter===x} onPress={()=>setFilter(x)}/>)}
      </ScrollView>

      {tab==="profile" ? <View style={{padding:20}}>
        <Text style={{color:C.text,fontSize:21,fontWeight:"900",textAlign:"right"}}>مرحباً بك في MOVIORA</Text>
        <Text style={{color:C.muted,textAlign:"right",marginTop:10,lineHeight:23}}>ملف الحساب وتسجيل الدخول والاشتراكات ستُربط بخدمة مصادقة آمنة في مرحلة إعداد الخادم.</Text>
        <View style={{backgroundColor:C.panel,padding:16,borderRadius:14,marginTop:18}}>
          <Text style={{color:C.gold,textAlign:"right",fontWeight:"800"}}>MOVIORA VIP</Text>
          <Text style={{color:C.muted,textAlign:"right",marginTop:8}}>ستظهر هنا خطط الاشتراك والدفع بعد ربط مزود دفع رسمي.</Text>
        </View>
      </View> : tab==="saved" ? <View style={{paddingHorizontal:18}}>
        {filtered.filter(x=>saved.includes(x.id)).length===0 ? <Text style={{color:C.muted,textAlign:"center",padding:35}}>لم تضف أعمالاً إلى قائمتك بعد</Text> :
          <View style={{flexDirection:"row",flexWrap:"wrap",justifyContent:"flex-end"}}>{filtered.filter(x=>saved.includes(x.id)).map(x=><Poster key={x.id} item={x} onPress={()=>setSelected(x)} compact/>)}</View>}
      </View> : <View style={{paddingHorizontal:18}}>
        <View style={{flexDirection:"row-reverse",alignItems:"center",justifyContent:"space-between",marginBottom:12}}>
          <Text style={{color:C.text,fontSize:18,fontWeight:"900",textAlign:"right"}}>{tab==="discover"?"كل الأعمال":"مختارات MOVIORA"}</Text>
          <Text style={{color:C.muted,fontSize:11}}>{filtered.length} أعمال تجريبية</Text>
        </View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{flexDirection:"row-reverse"}}>
          {filtered.map(x=><Poster key={x.id} item={x} onPress={()=>setSelected(x)}/>)}
        </ScrollView>
        <Text style={{color:C.text,fontSize:18,fontWeight:"900",textAlign:"right",marginTop:22,marginBottom:12}}>الأرشيف التاريخي</Text>
        <View style={{backgroundColor:C.panel,borderRadius:15,padding:16,borderWidth:1,borderColor:C.line}}>
          <Text style={{color:C.gold,fontSize:15,fontWeight:"900",textAlign:"right"}}>SOVIET & WORLD WAR ARCHIVE</Text>
          <Text style={{color:C.muted,fontSize:12,textAlign:"right",lineHeight:22,marginTop:7}}>تصنيف مخصص للأعمال السوفيتية والروسية والعالمية والوثائقيات التاريخية.</Text>
          <Pressable onPress={()=>{setTab("discover");setFilter("الحرب العالمية الثانية");}} style={{alignSelf:"flex-end",marginTop:12}}>
            <Text style={{color:C.gold,fontWeight:"800"}}>عرض أعمال الحرب العالمية الثانية ←</Text>
          </Pressable>
        </View>
      </View>}
    </ScrollView>

    <View style={{height:70,borderTopWidth:1,borderColor:C.line,backgroundColor:"#101016",flexDirection:"row",justifyContent:"space-around",alignItems:"center"}}>
      {tabs.map(([id,label],i)=><Pressable key={id} onPress={()=>setTab(id)} style={{alignItems:"center",minWidth:65}}>
        <Text style={{color:tab===id?C.gold:C.muted,fontSize:18}}>{["⌂","⌕","♡","◉"][i]}</Text>
        <Text style={{color:tab===id?C.gold:C.muted,fontSize:10,marginTop:3,fontWeight:tab===id?"900":"500"}}>{label}</Text>
      </Pressable>)}
    </View>

    <Modal visible={!!selected} transparent animationType="slide" onRequestClose={()=>setSelected(null)}>
      <View style={{flex:1,backgroundColor:"#000B",justifyContent:"flex-end"}}>
        <View style={{backgroundColor:C.panel,borderTopLeftRadius:24,borderTopRightRadius:24,padding:22,borderWidth:1,borderColor:C.line}}>
          {selected && <>
            <Text style={{color:C.gold,fontWeight:"900",letterSpacing:2}}>MOVIORA DETAILS</Text>
            <Text style={{color:C.text,fontSize:25,fontWeight:"900",textAlign:"right",marginTop:12}}>{selected.ar}</Text>
            <Text style={{color:C.muted,textAlign:"right",marginTop:5}}>{selected.title} • {selected.year} • {selected.country}</Text>
            <Text style={{color:C.text,textAlign:"right",lineHeight:24,marginTop:16}}>{selected.description}</Text>
            <Text style={{color:C.muted,textAlign:"right",marginTop:12}}>{selected.kind} • {selected.seasons} • {selected.genre}</Text>
            <Pressable onPress={()=>{setSelected(null);setPlayer(true);}} style={{backgroundColor:C.gold,padding:14,borderRadius:12,marginTop:20}}>
              <Text style={{color:C.bg,textAlign:"center",fontWeight:"900"}}>فتح صفحة المشاهدة</Text>
            </Pressable>
            <Pressable onPress={()=>toggleSaved(selected.id)} style={{padding:13,marginTop:5}}>
              <Text style={{color:C.gold,textAlign:"center",fontWeight:"800"}}>{saved.includes(selected.id)?"إزالة من قائمتي":"إضافة إلى قائمتي ♡"}</Text>
            </Pressable>
            <Pressable onPress={()=>setSelected(null)} style={{padding:8}}><Text style={{color:C.muted,textAlign:"center"}}>إغلاق</Text></Pressable>
          </>}
        </View>
      </View>
    </Modal>

    <Modal visible={player} transparent animationType="fade" onRequestClose={()=>setPlayer(false)}>
      <View style={{flex:1,backgroundColor:"#000",justifyContent:"center",padding:22}}>
        <Text style={{color:C.gold,fontSize:22,fontWeight:"900",textAlign:"center"}}>MOVIORA PLAYER</Text>
        <View style={{height:210,backgroundColor:"#171720",borderRadius:16,alignItems:"center",justifyContent:"center",marginTop:20,borderWidth:1,borderColor:C.line}}>
          <Text style={{fontSize:38,color:C.gold}}>▶</Text>
          <Text style={{color:C.text,fontWeight:"800",marginTop:12}}>منطقة تشغيل الفيديو</Text>
          <Text style={{color:C.muted,fontSize:11,marginTop:6}}>تحتاج إلى مصدر بث مرخص لبدء التشغيل</Text>
        </View>
        <Text style={{color:C.muted,textAlign:"center",lineHeight:23,marginTop:15}}>واجهة المشغل جاهزة كبداية. سيتم ربط HLS أو DASH والترجمة واختيار الجودة بعد توفير مصادر فيديو مرخصة.</Text>
        <Pressable onPress={()=>setPlayer(false)} style={{backgroundColor:C.gold,padding:14,borderRadius:12,marginTop:25}}><Text style={{color:C.bg,textAlign:"center",fontWeight:"900"}}>رجوع</Text></Pressable>
      </View>
    </Modal>
  </SafeAreaView>;
}
